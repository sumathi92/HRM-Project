drop database hrm;

create database hrm;
use hrm;
create table employeebean(EmployeeId blob(20),FirstName blob(40),LastName blob(40),FatherName blob(40),Gender blob(20),DateofBirth blob(30),EmailId blob(40),MobileNo blob,AadharNo blob,PermanatAddress blob(40),LocalAddress blob(40),SchoolName blob(40),TenthPassedOut int,IntermeadiateCollegeName blob(40),InterPassedOut int,GraduationDetails blob(40),GraduationPassedOut int,Branch blob(30),University blob(40),CompanyName blob(40),Role blob(30),NoticePeriod int,Location blob(40),Experience blob(40),CurrentCtc double,ExpectedCtc double);